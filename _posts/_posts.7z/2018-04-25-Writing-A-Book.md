---
layout: post
title: "Writing A Book"
tags: [Book]
comments: true
---

Hello! I'm just writing this blog post to announce that I'm writing a book! Nevermind the fact that I have to regularly keep my blog updated as a school assignment and that I'm really just writing this to fill up my post quota, this is meant to announce my book called "The Orokin" (Many names will have to be changed to Digital Extremes wont sue me to the void and back.)
