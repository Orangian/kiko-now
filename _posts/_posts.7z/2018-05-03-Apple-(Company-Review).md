---
layout: post
title: "Apple (Company Review)"
tags: [Mapple]
comments: true
---

Apple. Founded on April 1 1976, they quickly grew to be a tech giant. Led by founder Steve Jobs, they appeared unstoppable. They made good products for cheap, and they had ethical buisness practices. After a few power struggles, Steve Jobs was ejected from the company. Eventually, he became CEO again. Under his leadership, the company grew to be one of the largest tech companies in the world. If you look at apple today however, they are but a husk of their former selves. They have been using what can be compared to slaves to make their products, and they constantly rip off other companies while attempting to pass of features from other phones that have existed for years as their own revolutionary product. They have even tried to SUE people just for repairing their phones at a store not owned by apple. They use slave labor, they sell ten year old computers as "new" and "innovative" and they sue repair shops just for repairing apple producs. Overall, this company is terrible. I dont understand how they still exist. If I had to rate them ethically, I would give them a 0/1000000. If I had to rate their products, I would rate them a 0/1000000. This company is terrible.
