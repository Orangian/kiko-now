---
layout: post
title: "The End Of The School Year"
tags: [School]
comments: true
---

The school year is going to end soon. Near the end of the school year, my school always has us do fun activities. It's a nice way to end off the year. I can't wait until park day, or I-Space, or the pool party. I also can't wait until next year. Next year, we get to use Windows 10 laptops! I despise Chromebooks, (which is what we currently use in school) so it's nice to have a change to a full windows laptop. I will be able to use programs like photoshop, gimp, or GitHub desktop to do my work! It's going to be so fun. The end of the year, the summer, and next year will be so fun!
